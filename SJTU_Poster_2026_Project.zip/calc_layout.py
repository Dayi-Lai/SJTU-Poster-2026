from PIL import Image, ImageFont

SERIF_REG = '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf'

banner = Image.open('/home/ubuntu/poster/banner_new.png')
W = 1240
banner_h = int(banner.height * W / banner.width)
print(f'Banner: {W}x{banner_h}')

f_body = ImageFont.truetype(SERIF_REG, 20)
line_h = int((f_body.getbbox('Ay')[3] - f_body.getbbox('Ay')[1]) * 1.65)
print(f'Body line height at size 20: {line_h}px')

abstract = ('Have you ever considered how scaled-down building models (order of centimeters) can be used to '
    'analyze airflows around actual buildings (order of meters)? The answer lies in the concept of '
    'similarity - flows with similar dimensionless parameters behave the same way despite differences '
    'in scale, size, or other physical parameters. This seminar explores two errors commonly made in '
    'urban airflow modeling research. The behavior of airflows over buildings is determined by the '
    'dimensionless parameter Reynolds number, Re = UH/v, where U is a reference wind speed, H is the '
    'building height, and v is the kinematic viscosity of air. Real, full-scale buildings have H ranges '
    'from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and '
    '10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, '
    'resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re '
    'between scaled models and actual buildings is often circumvented using the Re-independent '
    'assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to '
    'real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the '
    'Re-independent assumption holds true only in simple cases, such as isothermal flows over a single '
    'building. Applying this assumption to more complex scenarios involving multiple buildings or heat '
    'transfer can lead to significant errors and incorrect predictions of the overall wind field around '
    'buildings. Some recent findings on similarity in urban airflow modeling will also be shared.')

PAD = 40
max_w = W - 2*PAD
words = abstract.split()
lines = []
current = []
for word in words:
    test = ' '.join(current + [word])
    w = f_body.getbbox(test)[2] - f_body.getbbox(test)[0]
    if w <= max_w:
        current.append(word)
    else:
        if current:
            lines.append(' '.join(current))
        current = [word]
if current:
    lines.append(' '.join(current))
print(f'Abstract lines: {len(lines)}, height: {len(lines)*line_h}px')

bio = ('Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, '
    'College of Design and Engineering at the National University of Singapore (NUS). He is the '
    'principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He '
    'obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior '
    'to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies '
    'in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the '
    'physics of flows, using both experimental and numerical approaches. In his free time, he '
    'enjoys reading, painting and traveling.')

RIGHT_W = W - (PAD + 270 + 35) - PAD
words2 = bio.split()
lines2 = []
current2 = []
for word in words2:
    test = ' '.join(current2 + [word])
    w = f_body.getbbox(test)[2] - f_body.getbbox(test)[0]
    if w <= RIGHT_W:
        current2.append(word)
    else:
        if current2:
            lines2.append(' '.join(current2))
        current2 = [word]
if current2:
    lines2.append(' '.join(current2))
print(f'Bio lines: {len(lines2)}, height: {len(lines2)*line_h}px')

HEADER_H = 115
BOTTOM_H = 310
BOTTOM_Y = 1754 - BOTTOM_H
available = BOTTOM_Y - HEADER_H - banner_h
print(f'Available for abstract+speaker: {available}px')
abstract_section_h = 28+44+14+len(lines)*line_h+28
speaker_h = 52 + len(lines2)*line_h + 30
print(f'Abstract section: {abstract_section_h}px')
print(f'Speaker section: {speaker_h}px')
print(f'Total content: {abstract_section_h + speaker_h}px')
print(f'Overflow: {abstract_section_h + speaker_h - available}px')
