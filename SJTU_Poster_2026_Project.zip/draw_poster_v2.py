#!/usr/bin/env python3
"""
Draw 2026 SJTU-ARCH Lecture Poster using PIL/Pillow directly.
Strictly follows 2024/2025 poster layout.
Resolution: 1240 x 1754 px (A4 @ 150dpi)
"""

from PIL import Image, ImageDraw, ImageFont, ImageOps
import os

# ============================================================
# CANVAS SETUP
# ============================================================
W = 1240
H = 1900  # extra height, will crop later
canvas = Image.new('RGB', (W, H), '#FFFFFF')
draw = ImageDraw.Draw(canvas)

# ============================================================
# COLORS
# ============================================================
RED_DARK = (139, 26, 26)
BEIGE = (240, 235, 227)
WHITE = (255, 255, 255)
BLACK = (34, 34, 34)
GRAY = (85, 85, 85)
LIGHT_GRAY = (204, 204, 204)

# ============================================================
# FONTS
# ============================================================
SERIF_REG = '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf'
SERIF_BOLD = '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf'
SANS_REG = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
SANS_BOLD = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
CJK_REG = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
CJK_BOLD = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'

def F(path, size):
    return ImageFont.truetype(path, size)

# ============================================================
# HELPER: draw justified text, return new y
# ============================================================
def draw_justified(draw, text, x, y, max_w, font, fill, line_spacing=1.65):
    words = text.split()
    lines = []
    current = []
    for word in words:
        test = ' '.join(current + [word])
        w = font.getbbox(test)[2] - font.getbbox(test)[0]
        if w <= max_w:
            current.append(word)
        else:
            if current:
                lines.append(' '.join(current))
            current = [word]
    if current:
        lines.append(' '.join(current))

    lh = font.getbbox('Ay')[3] - font.getbbox('Ay')[1]
    lh = int(lh * line_spacing)

    for i, line in enumerate(lines):
        lwords = line.split()
        if i == len(lines) - 1 or len(lwords) == 1:
            draw.text((x, y), line, font=font, fill=fill)
        else:
            total_ww = sum(font.getbbox(w)[2] - font.getbbox(w)[0] for w in lwords)
            gap = (max_w - total_ww) / (len(lwords) - 1)
            cx = x
            for j, word in enumerate(lwords):
                draw.text((int(cx), y), word, font=font, fill=fill)
                ww = font.getbbox(word)[2] - font.getbbox(word)[0]
                cx += ww + gap
        y += lh
    return y

# ============================================================
# LOAD IMAGES
# ============================================================
logo_img = Image.open('/home/ubuntu/poster/school_logo.png').convert('RGBA')
banner_img = Image.open('/home/ubuntu/poster/banner_new.png').convert('RGB')
photo_img = Image.open('/home/ubuntu/poster/photo.jpg').convert('RGB')
sjtu_img = Image.open('/home/ubuntu/poster/sjtu_logo_text.jpg').convert('RGB')

# ============================================================
# LAYOUT PLAN (all heights in px)
# Total: 1754px
# Header:   130px
# Banner:   480px (cropped from bottom to fit)
# Abstract: 440px
# Speaker:  394px
# Bottom:   310px
# Total:    130+480+440+394+310 = 1754 ✓
# ============================================================

PAD = 40
y = 0

# ============================================================
# SECTION 1: HEADER (115px)
# ============================================================
HEADER_H = 130

# Logo
logo_h = 85
logo_w = int(logo_img.width * logo_h / logo_img.height)
logo_resized = logo_img.resize((logo_w, logo_h), Image.LANCZOS)
logo_bg = Image.new('RGBA', (logo_w, logo_h), (255, 255, 255, 255))
logo_bg.paste(logo_resized, mask=logo_resized.split()[3])
canvas.paste(logo_bg.convert('RGB'), (PAD, 20))

# Series title CN
f_series_cn = F(CJK_REG, 28)
f_series_cn_bold = F(CJK_BOLD, 28)
series_cn_1 = '交大设计建筑学'
series_cn_2 = '建筑技术前沿系列讲座'
w1 = f_series_cn.getbbox(series_cn_1)[2] - f_series_cn.getbbox(series_cn_1)[0]
w2 = f_series_cn_bold.getbbox(series_cn_2)[2] - f_series_cn_bold.getbbox(series_cn_2)[0]
x_cn = W - PAD - w1 - w2
draw.text((x_cn, 20), series_cn_1, font=f_series_cn, fill=BLACK)
draw.text((x_cn + w1, 20), series_cn_2, font=f_series_cn_bold, fill=BLACK)

# Year font (define first to get width)
f_year = F(SERIF_BOLD, 90)
year_text = '2026'
w_year = f_year.getbbox(year_text)[2] - f_year.getbbox(year_text)[0]
year_h = f_year.getbbox(year_text)[3] - f_year.getbbox(year_text)[1]
year_y = (HEADER_H - year_h) // 2 - 5

# Series EN (two lines) - to the left of year
f_series_en = F(SANS_REG, 17)
en_line1 = 'SJTU-ARCH LECTURE SERIES OF'
en_line2 = 'BUILDING TECHNOLOGY'
w_en1 = f_series_en.getbbox(en_line1)[2] - f_series_en.getbbox(en_line1)[0]
w_en2 = f_series_en.getbbox(en_line2)[2] - f_series_en.getbbox(en_line2)[0]
draw.text((W - PAD - w_year - 14 - w_en1, 52), en_line1, font=f_series_en, fill=GRAY)
draw.text((W - PAD - w_year - 14 - w_en2, 72), en_line2, font=f_series_en, fill=GRAY)

# Year - draw last so it's on top
draw.text((W - PAD - w_year, year_y), year_text, font=f_year, fill=RED_DARK)

y = HEADER_H

# ============================================================
# SECTION 2: BANNER (full image, no crop)
# ============================================================
banner_full_w = W
banner_full_h = int(banner_img.height * W / banner_img.width)  # 716px
BANNER_H = banner_full_h
# Resize to full width
banner_resized = banner_img.resize((banner_full_w, banner_full_h), Image.LANCZOS)
canvas.paste(banner_resized, (0, y))
y += BANNER_H

# ============================================================
# SECTION 3: LECTURE ABSTRACT (450px)
# ============================================================
ABSTRACT_H = 355
y += 14  # top padding

# Heading
f_heading_en = F(SERIF_BOLD, 32)
f_heading_cn = F(CJK_BOLD, 26)
draw.text((PAD, y), 'LECTURE ABSTRACT', font=f_heading_en, fill=RED_DARK)
w_he = f_heading_en.getbbox('LECTURE ABSTRACT')[2] - f_heading_en.getbbox('LECTURE ABSTRACT')[0]
draw.text((PAD + w_he + 18, y + 4), '主讲内容', font=f_heading_cn, fill=BLACK)
y += 42

# Divider
draw.line([(PAD, y), (W - PAD, y)], fill=LIGHT_GRAY, width=2)
y += 14

# Abstract body
f_body = F(SERIF_REG, 18)
abstract_text = (
    "Have you ever considered how scaled-down building models (order of centimeters) can be used to "
    "analyze airflows around actual buildings (order of meters)? The answer lies in the concept of "
    "similarity - flows with similar dimensionless parameters behave the same way despite differences "
    "in scale, size, or other physical parameters. This seminar explores two errors commonly made in "
    "urban airflow modeling research. The behavior of airflows over buildings is determined by the "
    "dimensionless parameter Reynolds number, Re = UH/v, where U is a reference wind speed, H is the "
    "building height, and v is the kinematic viscosity of air. Real, full-scale buildings have H ranges "
    "from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and "
    "10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, "
    "resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re "
    "between scaled models and actual buildings is often circumvented using the Re-independent "
    "assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to "
    "real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the "
    "Re-independent assumption holds true only in simple cases, such as isothermal flows over a single "
    "building. Applying this assumption to more complex scenarios involving multiple buildings or heat "
    "transfer can lead to significant errors and incorrect predictions of the overall wind field around "
    "buildings. Some recent findings on similarity in urban airflow modeling will also be shared."
)
y = draw_justified(draw, abstract_text, PAD, y, W - 2*PAD, f_body, BLACK, line_spacing=1.6)
y += 10  # bottom padding

# ============================================================
# SECTION 4: SPEAKER (379px)
# ============================================================
SPEAKER_SECTION_Y = y
PHOTO_SIZE = 140
PHOTO_X = PAD
PHOTO_Y = y + 10

# Photo (square crop from top)
ph = photo_img.copy()
ph_w, ph_h = ph.size
if ph_w > ph_h:
    # landscape: crop center
    left = (ph_w - ph_h) // 2
    ph = ph.crop((left, 0, left + ph_h, ph_h))
else:
    # portrait: crop top portion
    ph = ph.crop((0, 0, ph_w, ph_w))
photo_resized = ph.resize((PHOTO_SIZE, PHOTO_SIZE), Image.LANCZOS)
canvas.paste(photo_resized, (PHOTO_X, PHOTO_Y))

# Caption below photo
f_caption_bold = F(SERIF_BOLD, 16)
f_caption = F(SERIF_REG, 16)
cap_y = PHOTO_Y + PHOTO_SIZE + 7
draw.text((PHOTO_X, cap_y), 'Dr. Chew Lup Wai', font=f_caption_bold, fill=BLACK)
cap_y += 20
for line in ['Assistant Professor,', 'College of Design & Engineering,',
             'NUS, Singapore.']:
    draw.text((PHOTO_X, cap_y), line, font=f_caption, fill=BLACK)
    cap_y += 20

# Right side
RIGHT_X = PHOTO_X + PHOTO_SIZE + 28
RIGHT_W = W - RIGHT_X - PAD

# Speaker name row
f_speaker_name = F(SERIF_BOLD, 38)
f_speaker_label = F(CJK_BOLD, 26)
draw.text((RIGHT_X, y + 10), 'CHEW LUP WAI', font=f_speaker_name, fill=BLACK)
w_name = f_speaker_name.getbbox('CHEW LUP WAI')[2] - f_speaker_name.getbbox('CHEW LUP WAI')[0]
draw.text((RIGHT_X + w_name + 16, y + 14), '个人介绍', font=f_speaker_label, fill=BLACK)

y_bio = y + 10 + 44

bio_text = (
    "Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, "
    "College of Design and Engineering at the National University of Singapore (NUS). He is the "
    "principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He "
    "obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior "
    "to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies "
    "in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the "
    "physics of flows, using both experimental and numerical approaches. In his free time, he "
    "enjoys reading, painting and traveling."
)
y_end = draw_justified(draw, bio_text, RIGHT_X, y_bio, RIGHT_W, f_body, BLACK, line_spacing=1.6)

# Caption left side bottom
cap_end = cap_y  # already drawn

# Speaker section ends at max of left and right
SPEAKER_END = max(y_end, cap_end) + 16

# ============================================================
# SECTION 5: BOTTOM BAR (310px at bottom)
# ============================================================
BOTTOM_H = 310
BOTTOM_Y = SPEAKER_END
print(f'Speaker section ends at y={SPEAKER_END}, bottom bar at y={BOTTOM_Y}')
print(f'Total height needed: {BOTTOM_Y + BOTTOM_H}px')

# Left half: dark red
draw.rectangle([(0, BOTTOM_Y), (W//2, H)], fill=RED_DARK)

# Watermark (very faint)
wm_canvas = Image.new('RGBA', (W//2, BOTTOM_H), (0, 0, 0, 0))
wm_draw = ImageDraw.Draw(wm_canvas)
f_wm = F(SERIF_BOLD, 72)
wm_draw.text((-10, 20), 'SHANGHAI JIAO', font=f_wm, fill=(255, 255, 255, 12))
wm_draw.text((-10, 100), 'TONG UNIVERSITY', font=f_wm, fill=(255, 255, 255, 12))
canvas_rgba = canvas.convert('RGBA')
canvas_rgba.paste(wm_canvas, (0, BOTTOM_Y), wm_canvas)
canvas = canvas_rgba.convert('RGB')
draw = ImageDraw.Draw(canvas)

# Lecture title CN
f_title_cn = F(CJK_BOLD, 48)
f_title_en = F(SERIF_REG, 24)

title_y = BOTTOM_Y + 28
for line in ['缩尺模型能否用于', '城市气流研究？']:
    draw.text((PAD, title_y), line, font=f_title_cn, fill=WHITE)
    lh = f_title_cn.getbbox(line)[3] - f_title_cn.getbbox(line)[1]
    title_y += lh + 6

title_y += 10
for line in ['Can We Study Urban Airflow', 'with Scaled-down Models?']:
    draw.text((PAD, title_y), line, font=f_title_en, fill=WHITE)
    lh = f_title_en.getbbox(line)[3] - f_title_en.getbbox(line)[1]
    title_y += lh + 4

# SJTU logo at bottom-left (white) - will be placed at FINAL_H - offset
# Placeholder - will draw after FINAL_H is known
SJTU_H_PX = 38
SJTU_W_PX = int(sjtu_img.width * SJTU_H_PX / sjtu_img.height)
sjtu_resized = sjtu_img.resize((SJTU_W_PX, SJTU_H_PX), Image.LANCZOS)
sjtu_inv = ImageOps.invert(sjtu_resized)

# Right half: beige
draw.rectangle([(W//2, BOTTOM_Y), (W, H)], fill=BEIGE)

# Watermark right (very faint red)
wm2 = Image.new('RGBA', (W//2, BOTTOM_H), (0, 0, 0, 0))
wm2_draw = ImageDraw.Draw(wm2)
f_wm2 = F(SERIF_BOLD, 60)
wm2_draw.text((10, 80), 'SCHOOL OF DESIGN', font=f_wm2, fill=(139, 26, 26, 10))
canvas_rgba2 = canvas.convert('RGBA')
canvas_rgba2.paste(wm2, (W//2, BOTTOM_Y), wm2)
canvas = canvas_rgba2.convert('RGB')
draw = ImageDraw.Draw(canvas)

# Info rows
f_label = F(CJK_BOLD, 24)
f_value = F(CJK_REG, 24)

INFO_X = W//2 + 36
info_y = BOTTOM_Y + 28

rows = [
    ('主办单位：', '上海交通大学设计学院', False),
    ('时　　间：', '03/30  时间待定', True),
    ('地　　点：', '上海交通大学闵行校区\n设计学院（具体房间待定）', False),
    ('主 持 人：', '待定', False),
]

for label, value, is_red in rows:
    lbl_w = f_label.getbbox(label)[2] - f_label.getbbox(label)[0]
    draw.text((INFO_X, info_y), label, font=f_label, fill=RED_DARK)
    val_color = RED_DARK if is_red else BLACK
    if '\n' in value:
        vlines = value.split('\n')
        vy = info_y
        vx = INFO_X + lbl_w + 4
        for vl in vlines:
            draw.text((vx, vy), vl, font=f_value, fill=val_color)
            vy += f_value.getbbox(vl)[3] - f_value.getbbox(vl)[1] + 3
        info_y = vy + 12
    else:
        draw.text((INFO_X + lbl_w + 4, info_y), value, font=f_value, fill=val_color)
        row_h = f_value.getbbox(value)[3] - f_value.getbbox(value)[1]
        info_y += row_h + 16

# ============================================================
# SAVE
# ============================================================
# Crop to actual content
FINAL_H = BOTTOM_Y + BOTTOM_H
# Draw SJTU logo now that we know FINAL_H
canvas.paste(sjtu_inv, (PAD, FINAL_H - SJTU_H_PX - 16))
draw = ImageDraw.Draw(canvas)
canvas_cropped = canvas.crop((0, 0, W, FINAL_H))
canvas_cropped.save('/home/ubuntu/poster/poster_2026_v2.jpg', 'JPEG', quality=95, dpi=(150, 150))
canvas_cropped.save('/home/ubuntu/poster/poster_2026_v2.png', 'PNG', dpi=(150, 150))
print(f"Poster saved! Size: {canvas_cropped.size}")
