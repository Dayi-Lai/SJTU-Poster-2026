#!/usr/bin/env python3
"""Generate the 2026 SJTU-ARCH Lecture Series poster as HTML - v2 refined."""

import base64
from pathlib import Path

# Read base64 encoded images
photo_b64 = Path('/home/ubuntu/poster/photo_b64.txt').read_text()
banner_b64 = Path('/home/ubuntu/poster/banner_b64.txt').read_text()

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SJTU-ARCH Lecture Series 2026</title>
<style>
@page {{
  size: 800px 1180px;
  margin: 0;
}}
* {{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}}
body {{
  width: 800px;
  height: 1180px;
  font-family: 'SimSun', 'Noto Serif CJK SC', 'Source Han Serif SC', 'STSong', serif;
  background: #ffffff;
  overflow: hidden;
  position: relative;
}}

/* ===== HEADER SECTION ===== */
.header {{
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 20px 28px 10px 28px;
  background: #fff;
}}
.header-left {{
  display: flex;
  align-items: flex-start;
  gap: 8px;
}}
.school-logo {{
  width: 50px;
  height: 50px;
  flex-shrink: 0;
}}
.school-name {{
  display: flex;
  flex-direction: column;
  gap: 1px;
}}
.school-name .cn {{
  font-size: 19px;
  font-weight: bold;
  color: #222;
  letter-spacing: 3px;
}}
.school-name .en {{
  font-size: 9.5px;
  color: #555;
  font-family: 'Georgia', serif;
  letter-spacing: 0.5px;
  font-weight: bold;
}}
.school-name .dept {{
  font-size: 7.5px;
  color: #777;
  font-family: 'Georgia', serif;
  letter-spacing: 0.3px;
  margin-top: 1px;
}}
.header-right {{
  text-align: right;
  padding-top: 0;
}}
.header-right .series-cn {{
  font-size: 15px;
  color: #333;
  letter-spacing: 1px;
}}
.header-right .series-cn .bold-part {{
  font-weight: bold;
  color: #8B1A1A;
}}
.header-right .series-en {{
  font-size: 9.5px;
  color: #555;
  font-family: 'Georgia', serif;
  letter-spacing: 0.5px;
  margin-top: 3px;
  line-height: 1.4;
}}
.header-right .year {{
  font-size: 56px;
  font-weight: bold;
  color: #8B1A1A;
  font-family: 'Georgia', 'Times New Roman', serif;
  line-height: 1;
  margin-top: 0px;
}}

/* ===== BANNER IMAGE ===== */
.banner {{
  width: 100%;
  height: 220px;
  overflow: hidden;
  position: relative;
}}
.banner img {{
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center 35%;
}}

/* ===== LECTURE ABSTRACT SECTION ===== */
.abstract-section {{
  padding: 16px 28px 8px 28px;
}}
.abstract-title {{
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin-bottom: 8px;
  border-bottom: 1.5px solid #ddd;
  padding-bottom: 5px;
}}
.abstract-title .en {{
  font-size: 16px;
  font-family: 'Georgia', serif;
  color: #8B1A1A;
  font-weight: bold;
  letter-spacing: 2px;
}}
.abstract-title .cn {{
  font-size: 14px;
  color: #333;
  font-weight: bold;
}}
.abstract-text {{
  font-size: 10.2px;
  line-height: 1.6;
  color: #333;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ===== SPEAKER SECTION ===== */
.speaker-section {{
  display: flex;
  padding: 12px 28px 0px 28px;
  gap: 18px;
  align-items: flex-start;
}}
.speaker-photo-block {{
  flex-shrink: 0;
  width: 175px;
}}
.speaker-photo {{
  width: 175px;
  height: 175px;
  object-fit: cover;
  border-radius: 3px;
}}
.speaker-title-block {{
  margin-top: 8px;
  font-size: 8.5px;
  line-height: 1.45;
  color: #333;
  font-family: 'Georgia', serif;
}}
.speaker-info {{
  flex: 1;
}}
.speaker-name-row {{
  display: flex;
  align-items: baseline;
  gap: 12px;
  margin-bottom: 6px;
}}
.speaker-name {{
  font-size: 22px;
  font-weight: bold;
  color: #333;
  font-family: 'Georgia', serif;
  letter-spacing: 2px;
}}
.speaker-label {{
  font-size: 14px;
  color: #333;
  font-weight: bold;
}}
.speaker-bio {{
  font-size: 10.2px;
  line-height: 1.6;
  color: #333;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ===== BOTTOM SECTION ===== */
.bottom-section {{
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 195px;
  display: flex;
}}
.bottom-left {{
  width: 50%;
  background: #8B1A1A;
  color: #fff;
  padding: 18px 22px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  overflow: hidden;
}}
.bottom-left::before {{
  content: 'SHANGHAI JIAO TONG UNIVERSITY';
  position: absolute;
  top: -5px;
  left: -5px;
  right: -5px;
  bottom: -5px;
  font-size: 40px;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(255,255,255,0.05);
  line-height: 1.05;
  padding: 8px;
  word-break: break-all;
  overflow: hidden;
  z-index: 0;
}}
.lecture-title-cn {{
  font-size: 23px;
  font-weight: bold;
  line-height: 1.45;
  position: relative;
  z-index: 1;
  letter-spacing: 1px;
}}
.lecture-title-en {{
  font-size: 11.5px;
  line-height: 1.45;
  margin-top: 8px;
  position: relative;
  z-index: 1;
  font-family: 'Georgia', serif;
  opacity: 0.95;
}}

/* SJTU Logo at bottom-left */
.sjtu-bottom-logo {{
  position: absolute;
  bottom: 10px;
  left: 18px;
  display: flex;
  align-items: center;
  gap: 6px;
  z-index: 2;
}}
.sjtu-bottom-logo svg {{
  width: 28px;
  height: 28px;
}}
.sjtu-bottom-logo .sjtu-text {{
  display: flex;
  flex-direction: column;
}}
.sjtu-bottom-logo .sjtu-cn {{
  font-size: 13px;
  color: #fff;
  font-weight: bold;
  letter-spacing: 2px;
  opacity: 0.9;
}}
.sjtu-bottom-logo .sjtu-en {{
  font-size: 6px;
  color: #fff;
  opacity: 0.7;
  font-family: 'Georgia', serif;
  letter-spacing: 0.3px;
}}

.bottom-right {{
  width: 50%;
  background: #f5f0eb;
  padding: 18px 22px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  overflow: hidden;
}}
.bottom-right::before {{
  content: 'SCHOOL OF DESIGN';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-15deg);
  font-size: 44px;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(139,26,26,0.04);
  white-space: nowrap;
  z-index: 0;
}}
.info-row {{
  display: flex;
  margin-bottom: 9px;
  font-size: 12.5px;
  position: relative;
  z-index: 1;
  line-height: 1.5;
}}
.info-label {{
  color: #8B1A1A;
  font-weight: bold;
  min-width: 65px;
  flex-shrink: 0;
}}
.info-value {{
  color: #333;
}}
.info-value .highlight {{
  color: #8B1A1A;
  font-weight: bold;
}}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="header-left">
    <div class="school-logo">
      <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="2" width="46" height="46" rx="5" fill="none" stroke="#333" stroke-width="1.8"/>
        <circle cx="25" cy="14" r="6" fill="none" stroke="#333" stroke-width="1.2"/>
        <text x="25" y="16.5" text-anchor="middle" font-size="6" fill="#333" font-family="serif" font-weight="bold">交</text>
        <text x="25" y="30" text-anchor="middle" font-size="10" font-weight="bold" fill="#333" font-family="serif">设计</text>
        <text x="25" y="38" text-anchor="middle" font-size="10" font-weight="bold" fill="#333" font-family="serif">学院</text>
        <text x="25" y="45" text-anchor="middle" font-size="4.5" fill="#555" font-family="Georgia, serif">DESIGN</text>
      </svg>
    </div>
    <div class="school-name">
      <span class="cn">设计学院</span>
      <span class="en">SCHOOL OF DESIGN</span>
      <span class="dept">ARCHITECTURE 建筑 / DESIGN 设计</span>
      <span class="dept">LANDSCAPE ARCHITECTURE 风景园林</span>
    </div>
  </div>
  <div class="header-right">
    <div class="series-cn">交大设计建筑学<span class="bold-part">建筑技术前沿系列讲座</span></div>
    <div class="series-en">SJTU-ARCH LECTURE SERIES OF<br>BUILDING TECHNOLOGY</div>
    <div class="year">2026</div>
  </div>
</div>

<!-- BANNER -->
<div class="banner">
  <img src="data:image/jpeg;base64,{banner_b64}" alt="Urban Wind Simulation">
</div>

<!-- LECTURE ABSTRACT -->
<div class="abstract-section">
  <div class="abstract-title">
    <span class="en">LECTURE ABSTRACT</span>
    <span class="cn">主讲内容</span>
  </div>
  <div class="abstract-text">
    Have you ever considered how scaled-down building models (order of centimeters) can be used to analyze airflows around actual buildings (order of meters)? The answer lies in the concept of similarity &ndash; flows with similar dimensionless parameters behave the same way despite differences in scale, size, or other physical parameters. This seminar explores two errors commonly made in urban airflow modeling research. The behavior of airflows over buildings is determined by the dimensionless parameter Reynolds number, Re&nbsp;=&nbsp;UH/&nu;, where U is a reference wind speed, H is the building height, and &nu; is the kinematic viscosity of air. Real, full-scale buildings have H ranges from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and 10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re between scaled models and actual buildings is often circumvented using the Re-independent assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the Re-independent assumption holds true only in simple cases, such as isothermal flows over a single building. Applying this assumption to more complex scenarios involving multiple buildings or heat transfer can lead to significant errors and incorrect predictions of the overall wind field around buildings. Some recent findings on similarity in urban airflow modeling will also be shared.
  </div>
</div>

<!-- SPEAKER SECTION -->
<div class="speaker-section">
  <div class="speaker-photo-block">
    <img class="speaker-photo" src="data:image/jpeg;base64,{photo_b64}" alt="Dr. Chew Lup Wai">
    <div class="speaker-title-block">
      <strong>Dr. Chew Lup Wai</strong><br>
      Assistant Professor,<br>
      Department of the Built<br>
      Environment, College of Design<br>
      and Engineering,<br>
      National University of Singapore.
    </div>
  </div>
  <div class="speaker-info">
    <div class="speaker-name-row">
      <span class="speaker-name">CHEW LUP WAI</span>
      <span class="speaker-label">个人介绍</span>
    </div>
    <div class="speaker-bio">
      Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, College of Design and Engineering at the National University of Singapore (NUS). He is the principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the physics of flows, using both experimental and numerical approaches. In his free time, he enjoys reading, painting and traveling.
    </div>
  </div>
</div>

<!-- BOTTOM SECTION -->
<div class="bottom-section">
  <div class="bottom-left">
    <div class="lecture-title-cn">缩尺模型能否用于<br>城市气流研究？</div>
    <div class="lecture-title-en">Can We Study Urban Airflow<br>with Scaled-down Models?</div>
    
    <!-- SJTU Logo -->
    <div class="sjtu-bottom-logo">
      <svg viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
        <circle cx="15" cy="15" r="13.5" fill="none" stroke="rgba(255,255,255,0.8)" stroke-width="1"/>
        <circle cx="15" cy="15" r="11" fill="none" stroke="rgba(255,255,255,0.6)" stroke-width="0.5"/>
        <text x="15" y="13" text-anchor="middle" font-size="5.5" fill="rgba(255,255,255,0.85)" font-family="serif" font-weight="bold">交大</text>
        <text x="15" y="19.5" text-anchor="middle" font-size="3.8" fill="rgba(255,255,255,0.85)" font-family="serif">1896</text>
      </svg>
      <div class="sjtu-text">
        <span class="sjtu-cn">上海交通大学</span>
        <span class="sjtu-en">SHANGHAI JIAO TONG UNIVERSITY</span>
      </div>
    </div>
  </div>
  <div class="bottom-right">
    <div class="info-row">
      <span class="info-label">主办单位：</span>
      <span class="info-value">上海交通大学设计学院</span>
    </div>
    <div class="info-row">
      <span class="info-label">时　　间：</span>
      <span class="info-value"><span class="highlight">03/30 时间待定</span></span>
    </div>
    <div class="info-row">
      <span class="info-label">地　　点：</span>
      <span class="info-value">上海交通大学闵行校区<br><span style="margin-left: 0px;">设计学院（具体房间待定）</span></span>
    </div>
    <div class="info-row">
      <span class="info-label">主 持 人：</span>
      <span class="info-value">待定</span>
    </div>
  </div>
</div>

</body>
</html>"""

Path('/home/ubuntu/poster/poster_v2.html').write_text(html)
print("HTML poster v2 generated successfully!")
