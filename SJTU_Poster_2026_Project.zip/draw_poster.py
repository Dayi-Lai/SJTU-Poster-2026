#!/usr/bin/env python3
"""
Draw 2026 SJTU-ARCH Lecture Poster using PIL/Pillow directly.
Strictly follows 2024/2025 poster layout.
"""

from PIL import Image, ImageDraw, ImageFont, ImageOps
import textwrap
import os

# ============================================================
# CANVAS SETUP
# A4 at 150dpi: 1240 x 1754 px
# ============================================================
W = 1240
H = 1754
DPI = 150

canvas = Image.new('RGB', (W, H), '#FFFFFF')
draw = ImageDraw.Draw(canvas)

# ============================================================
# COLORS
# ============================================================
RED_DARK = '#8B1A1A'
BEIGE = '#f0ebe3'
WHITE = '#FFFFFF'
BLACK = '#222222'
GRAY = '#555555'
LIGHT_GRAY = '#cccccc'

# ============================================================
# FONTS - use default or find system fonts
# ============================================================
def get_font(size, bold=False):
    """Try to load a good font, fall back to default."""
    font_paths = []
    if bold:
        font_paths = [
            '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf',
            '/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',
            '/usr/share/fonts/truetype/noto/NotoSerif-Bold.ttf',
        ]
    else:
        font_paths = [
            '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf',
            '/usr/share/fonts/truetype/freefont/FreeSerif.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf',
            '/usr/share/fonts/truetype/noto/NotoSerif-Regular.ttf',
        ]
    for fp in font_paths:
        if os.path.exists(fp):
            return ImageFont.truetype(fp, size)
    return ImageFont.load_default()

def get_sans_font(size, bold=False):
    """Try to load a sans-serif font."""
    font_paths = []
    if bold:
        font_paths = [
            '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
            '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
            '/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf',
        ]
    else:
        font_paths = [
            '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
            '/usr/share/fonts/truetype/freefont/FreeSans.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',
        ]
    for fp in font_paths:
        if os.path.exists(fp):
            return ImageFont.truetype(fp, size)
    return ImageFont.load_default()

def get_cjk_font(size, bold=False):
    """Try to load a CJK font."""
    font_paths = [
        '/usr/share/fonts/truetype/noto/NotoSerifCJKsc-Regular.otf',
        '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc',
        '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    ]
    for fp in font_paths:
        if os.path.exists(fp):
            return ImageFont.truetype(fp, size)
    return get_font(size, bold)

# Check available fonts
import subprocess
result = subprocess.run(['fc-list', ':lang=zh'], capture_output=True, text=True)
print("CJK fonts available:")
print(result.stdout[:500])

result2 = subprocess.run(['find', '/usr/share/fonts', '-name', '*.ttf', '-o', '-name', '*.otf', '-o', '-name', '*.ttc'], capture_output=True, text=True)
print("\nAll fonts:")
print(result2.stdout[:1000])
