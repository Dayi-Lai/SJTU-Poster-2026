# SJTU-Poster-2026
2026 SJTU-ARCH Lecture Poster Project for CHEW Lup Wai.
