#!/usr/bin/env python3
"""
Generate 2026 SJTU-ARCH Lecture Poster - v6.
Use full flexbox column layout with explicit heights.
Page: 595pt wide, auto height (no overflow:hidden on body).
Bottom bar uses normal flow (not absolute).
"""

import base64
from pathlib import Path

logo_b64 = Path('/home/ubuntu/poster/logo_b64.txt').read_text()
banner_b64 = Path('/home/ubuntu/poster/banner_new_b64.txt').read_text()
photo_b64 = Path('/home/ubuntu/poster/photo_b64.txt').read_text()

with open('/home/ubuntu/poster/sjtu_logo_text.jpg', 'rb') as f:
    sjtu_b64 = base64.b64encode(f.read()).decode()

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>SJTU-ARCH Lecture Series 2026 - Chew Lup Wai</title>
<style>
@page {{
  size: 595pt auto;
  margin: 0;
}}

* {{ margin:0; padding:0; box-sizing:border-box; }}

body {{
  width: 595pt;
  background: #fff;
  font-family: 'SimSun', 'STSong', 'Noto Serif SC', serif;
}}

/* ============================================================
   SECTION 1: HEADER
   ============================================================ */
.header {{
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 14pt 18pt 8pt 15pt;
  background: #fff;
}}

.header-logo img {{
  height: 50pt;
  width: auto;
  display: block;
}}

.header-right {{
  text-align: right;
  line-height: 1.25;
}}
.header-series-cn {{
  font-size: 11.5pt;
  color: #222;
  letter-spacing: 0.5px;
}}
.header-series-cn .bold {{
  font-weight: bold;
  color: #222;
}}
.header-series-en {{
  font-size: 7pt;
  color: #555;
  font-family: 'Arial', sans-serif;
  letter-spacing: 0.8px;
  margin-top: 2pt;
  text-transform: uppercase;
  line-height: 1.4;
}}
.header-year {{
  font-size: 48pt;
  font-weight: bold;
  color: #8B1A1A;
  font-family: 'Georgia', 'Times New Roman', serif;
  line-height: 1;
  margin-top: -2pt;
  letter-spacing: -1px;
}}

/* ============================================================
   SECTION 2: BANNER IMAGE - full image
   ============================================================ */
.banner {{
  width: 100%;
  line-height: 0;
}}
.banner img {{
  width: 100%;
  height: auto;
  display: block;
}}

/* ============================================================
   SECTION 3: LECTURE ABSTRACT
   ============================================================ */
.abstract-section {{
  padding: 14pt 18pt 10pt 18pt;
}}
.section-heading {{
  display: flex;
  align-items: baseline;
  gap: 8pt;
  margin-bottom: 7pt;
  border-bottom: 0.8pt solid #ccc;
  padding-bottom: 4pt;
}}
.section-heading .en {{
  font-size: 13pt;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: #8B1A1A;
  letter-spacing: 2px;
  text-transform: uppercase;
}}
.section-heading .cn {{
  font-size: 11pt;
  font-weight: bold;
  color: #222;
}}
.abstract-body {{
  font-size: 8pt;
  line-height: 1.65;
  color: #222;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ============================================================
   SECTION 4: SPEAKER
   ============================================================ */
.speaker-section {{
  display: flex;
  padding: 10pt 18pt 14pt 18pt;
  gap: 14pt;
  align-items: flex-start;
}}
.speaker-left {{
  flex-shrink: 0;
  width: 130pt;
}}
.speaker-photo {{
  width: 130pt;
  height: 130pt;
  object-fit: cover;
  object-position: center top;
  display: block;
}}
.speaker-caption {{
  margin-top: 6pt;
  font-size: 7pt;
  line-height: 1.5;
  color: #333;
  font-family: 'Georgia', serif;
}}
.speaker-caption strong {{
  font-size: 8pt;
  display: block;
  margin-bottom: 1pt;
}}
.speaker-right {{
  flex: 1;
}}
.speaker-name-row {{
  display: flex;
  align-items: baseline;
  gap: 10pt;
  margin-bottom: 6pt;
}}
.speaker-name {{
  font-size: 17pt;
  font-weight: bold;
  color: #222;
  font-family: 'Georgia', serif;
  letter-spacing: 2px;
}}
.speaker-cn-label {{
  font-size: 11pt;
  font-weight: bold;
  color: #222;
}}
.speaker-bio {{
  font-size: 8pt;
  line-height: 1.65;
  color: #222;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ============================================================
   SECTION 5: BOTTOM BAR (normal flow, at bottom)
   ============================================================ */
.bottom-bar {{
  display: flex;
  width: 100%;
  height: 155pt;
}}

/* Left: dark red */
.bottom-left {{
  width: 50%;
  background-color: #8B1A1A;
  color: #fff;
  padding: 16pt 18pt 36pt 18pt;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
}}
.bottom-left::before {{
  content: 'SHANGHAI JIAO TONG UNIVERSITY';
  position: absolute;
  top: 0; left: -8pt; right: -8pt; bottom: 0;
  font-size: 34pt;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(255,255,255,0.055);
  line-height: 1.05;
  padding: 6pt;
  word-break: break-all;
  overflow: hidden;
  z-index: 0;
  pointer-events: none;
}}
.lecture-title-cn {{
  font-size: 20pt;
  font-weight: bold;
  line-height: 1.4;
  position: relative;
  z-index: 1;
  letter-spacing: 0.5px;
}}
.lecture-title-en {{
  font-size: 9pt;
  line-height: 1.45;
  margin-top: 8pt;
  position: relative;
  z-index: 1;
  font-family: 'Georgia', serif;
  opacity: 0.95;
}}
.sjtu-logo-bar {{
  position: absolute;
  bottom: 8pt;
  left: 14pt;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 5pt;
}}
.sjtu-logo-bar img {{
  height: 22pt;
  width: auto;
  filter: brightness(0) invert(1);
  opacity: 0.85;
}}

/* Right: beige */
.bottom-right {{
  width: 50%;
  background-color: #f0ebe3;
  padding: 16pt 18pt 16pt 18pt;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
}}
.bottom-right::before {{
  content: 'SCHOOL OF DESIGN';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-15deg);
  font-size: 36pt;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(139,26,26,0.04);
  white-space: nowrap;
  z-index: 0;
  pointer-events: none;
}}
.info-row {{
  display: flex;
  align-items: flex-start;
  margin-bottom: 7pt;
  font-size: 10pt;
  line-height: 1.5;
  position: relative;
  z-index: 1;
}}
.info-label {{
  color: #8B1A1A;
  font-weight: bold;
  min-width: 52pt;
  flex-shrink: 0;
}}
.info-value {{
  color: #222;
}}
.info-value .red {{
  color: #8B1A1A;
  font-weight: bold;
}}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="header-logo">
    <img src="data:image/png;base64,{logo_b64}" alt="设计学院 School of Design">
  </div>
  <div class="header-right">
    <div class="header-series-cn">交大设计建筑学<span class="bold">建筑技术前沿系列讲座</span></div>
    <div class="header-series-en">SJTU-ARCH LECTURE SERIES OF<br>BUILDING TECHNOLOGY</div>
    <div class="header-year">2026</div>
  </div>
</div>

<!-- BANNER (full image, no crop) -->
<div class="banner">
  <img src="data:image/png;base64,{banner_b64}" alt="Urban Airflow Scaled-down Models">
</div>

<!-- LECTURE ABSTRACT -->
<div class="abstract-section">
  <div class="section-heading">
    <span class="en">LECTURE ABSTRACT</span>
    <span class="cn">主讲内容</span>
  </div>
  <div class="abstract-body">
    Have you ever considered how scaled-down building models (order of centimeters) can be used to analyze airflows around actual buildings (order of meters)? The answer lies in the concept of similarity &ndash; flows with similar dimensionless parameters behave the same way despite differences in scale, size, or other physical parameters. This seminar explores two errors commonly made in urban airflow modeling research. The behavior of airflows over buildings is determined by the dimensionless parameter Reynolds number, Re&nbsp;=&nbsp;UH/&nu;, where U is a reference wind speed, H is the building height, and &nu; is the kinematic viscosity of air. Real, full-scale buildings have H ranges from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and 10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re between scaled models and actual buildings is often circumvented using the Re-independent assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the Re-independent assumption holds true only in simple cases, such as isothermal flows over a single building. Applying this assumption to more complex scenarios involving multiple buildings or heat transfer can lead to significant errors and incorrect predictions of the overall wind field around buildings. Some recent findings on similarity in urban airflow modeling will also be shared.
  </div>
</div>

<!-- SPEAKER -->
<div class="speaker-section">
  <div class="speaker-left">
    <img class="speaker-photo" src="data:image/jpeg;base64,{photo_b64}" alt="Dr. Chew Lup Wai">
    <div class="speaker-caption">
      <strong>Dr. Chew Lup Wai</strong>
      Assistant Professor,<br>
      Department of the Built<br>
      Environment, College of Design<br>
      and Engineering,<br>
      National University of<br>
      Singapore (NUS).
    </div>
  </div>
  <div class="speaker-right">
    <div class="speaker-name-row">
      <span class="speaker-name">CHEW LUP WAI</span>
      <span class="speaker-cn-label">个人介绍</span>
    </div>
    <div class="speaker-bio">
      Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, College of Design and Engineering at the National University of Singapore (NUS). He is the principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the physics of flows, using both experimental and numerical approaches. In his free time, he enjoys reading, painting and traveling.
    </div>
  </div>
</div>

<!-- BOTTOM BAR -->
<div class="bottom-bar">
  <div class="bottom-left">
    <div class="lecture-title-cn">缩尺模型能否用于<br>城市气流研究？</div>
    <div class="lecture-title-en">Can We Study Urban Airflow<br>with Scaled-down Models?</div>
    <div class="sjtu-logo-bar">
      <img src="data:image/jpeg;base64,{sjtu_b64}" alt="上海交通大学">
    </div>
  </div>
  <div class="bottom-right">
    <div class="info-row">
      <span class="info-label">主办单位：</span>
      <span class="info-value">上海交通大学设计学院</span>
    </div>
    <div class="info-row">
      <span class="info-label">时　　间：</span>
      <span class="info-value"><span class="red">03/30 时间待定</span></span>
    </div>
    <div class="info-row">
      <span class="info-label">地　　点：</span>
      <span class="info-value">上海交通大学闵行校区<br>设计学院（具体房间待定）</span>
    </div>
    <div class="info-row">
      <span class="info-label">主 持 人：</span>
      <span class="info-value">待定</span>
    </div>
  </div>
</div>

</body>
</html>"""

Path('/home/ubuntu/poster/poster_v6.html').write_text(html)
print("poster_v6.html generated!")
