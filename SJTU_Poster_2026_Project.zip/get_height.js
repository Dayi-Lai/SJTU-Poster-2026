const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch({args: ['--no-sandbox']});
  const page = await browser.newPage();
  await page.setViewport({width: 1785, height: 800});
  await page.goto('file:///home/ubuntu/poster/poster_v6.html');
  const height = await page.evaluate(() => document.body.scrollHeight);
  console.log('Page height:', height);
  await browser.close();
})();
