#!/usr/bin/env python3
"""Generate the 2026 SJTU-ARCH Lecture Series poster as HTML."""

import base64
from pathlib import Path

# Read base64 encoded images
photo_b64 = Path('/home/ubuntu/poster/photo_b64.txt').read_text()
banner_b64 = Path('/home/ubuntu/poster/banner_b64.txt').read_text()

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SJTU-ARCH Lecture Series 2026</title>
<style>
@page {{
  size: 800px 1200px;
  margin: 0;
}}
* {{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}}
body {{
  width: 800px;
  height: 1200px;
  font-family: 'SimSun', 'Noto Serif CJK SC', 'Source Han Serif SC', serif;
  background: #ffffff;
  overflow: hidden;
  position: relative;
}}

/* ===== HEADER SECTION ===== */
.header {{
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 22px 30px 12px 30px;
  background: #fff;
}}
.header-left {{
  display: flex;
  align-items: flex-start;
  gap: 10px;
}}
.school-logo {{
  width: 48px;
  height: 48px;
}}
.school-logo svg {{
  width: 48px;
  height: 48px;
}}
.school-name {{
  display: flex;
  flex-direction: column;
  gap: 2px;
}}
.school-name .cn {{
  font-size: 18px;
  font-weight: bold;
  color: #333;
  letter-spacing: 2px;
}}
.school-name .en {{
  font-size: 9px;
  color: #666;
  font-family: 'Georgia', serif;
  letter-spacing: 0.5px;
}}
.school-name .dept {{
  font-size: 8px;
  color: #888;
  font-family: 'Georgia', serif;
  letter-spacing: 0.3px;
}}
.header-right {{
  text-align: right;
  padding-top: 2px;
}}
.header-right .series-cn {{
  font-size: 14px;
  color: #333;
  letter-spacing: 1px;
}}
.header-right .series-cn .bold-part {{
  font-weight: bold;
  color: #8B1A1A;
}}
.header-right .series-en {{
  font-size: 9px;
  color: #666;
  font-family: 'Georgia', serif;
  letter-spacing: 0.5px;
  margin-top: 2px;
}}
.header-right .year {{
  font-size: 52px;
  font-weight: bold;
  color: #8B1A1A;
  font-family: 'Georgia', 'Times New Roman', serif;
  line-height: 1;
  margin-top: -2px;
}}

/* ===== BANNER IMAGE ===== */
.banner {{
  width: 100%;
  height: 230px;
  overflow: hidden;
  position: relative;
}}
.banner img {{
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center 40%;
}}

/* ===== LECTURE ABSTRACT SECTION ===== */
.abstract-section {{
  padding: 18px 30px 10px 30px;
}}
.abstract-title {{
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin-bottom: 10px;
  border-bottom: 1px solid #ddd;
  padding-bottom: 6px;
}}
.abstract-title .en {{
  font-size: 16px;
  font-family: 'Georgia', serif;
  color: #8B1A1A;
  font-weight: bold;
  letter-spacing: 2px;
}}
.abstract-title .cn {{
  font-size: 14px;
  color: #333;
  font-weight: bold;
}}
.abstract-text {{
  font-size: 10px;
  line-height: 1.65;
  color: #333;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ===== SPEAKER SECTION ===== */
.speaker-section {{
  display: flex;
  padding: 14px 30px 10px 30px;
  gap: 20px;
  align-items: flex-start;
}}
.speaker-photo-block {{
  flex-shrink: 0;
  width: 180px;
}}
.speaker-photo {{
  width: 180px;
  height: 180px;
  object-fit: cover;
  border-radius: 4px;
}}
.speaker-title-block {{
  margin-top: 10px;
  font-size: 9px;
  line-height: 1.5;
  color: #333;
  font-family: 'Georgia', serif;
}}
.speaker-info {{
  flex: 1;
}}
.speaker-name-row {{
  display: flex;
  align-items: baseline;
  gap: 12px;
  margin-bottom: 8px;
}}
.speaker-name {{
  font-size: 22px;
  font-weight: bold;
  color: #333;
  font-family: 'Georgia', serif;
  letter-spacing: 2px;
}}
.speaker-label {{
  font-size: 14px;
  color: #333;
  font-weight: bold;
}}
.speaker-bio {{
  font-size: 10px;
  line-height: 1.65;
  color: #333;
  text-align: justify;
  font-family: 'Georgia', 'Times New Roman', serif;
}}

/* ===== BOTTOM SECTION ===== */
.bottom-section {{
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 200px;
  display: flex;
}}
.bottom-left {{
  width: 50%;
  background: #8B1A1A;
  color: #fff;
  padding: 20px 25px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
}}
.bottom-left::before {{
  content: 'SHANGHAI JIAO TONG UNIVERSITY';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  font-size: 38px;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(255,255,255,0.06);
  line-height: 1.1;
  padding: 10px;
  word-break: break-all;
  overflow: hidden;
  z-index: 0;
}}
.lecture-title-cn {{
  font-size: 22px;
  font-weight: bold;
  line-height: 1.4;
  position: relative;
  z-index: 1;
  letter-spacing: 1px;
}}
.lecture-title-en {{
  font-size: 11px;
  line-height: 1.5;
  margin-top: 8px;
  position: relative;
  z-index: 1;
  font-family: 'Georgia', serif;
  opacity: 0.95;
}}
.bottom-right {{
  width: 50%;
  background: #f5f0eb;
  padding: 20px 25px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
}}
.bottom-right::before {{
  content: 'SCHOOL OF DESIGN';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-15deg);
  font-size: 42px;
  font-family: 'Georgia', serif;
  font-weight: bold;
  color: rgba(139,26,26,0.04);
  white-space: nowrap;
  z-index: 0;
}}
.info-row {{
  display: flex;
  margin-bottom: 8px;
  font-size: 12px;
  position: relative;
  z-index: 1;
}}
.info-label {{
  color: #8B1A1A;
  font-weight: bold;
  min-width: 60px;
  flex-shrink: 0;
}}
.info-value {{
  color: #333;
}}
.info-value .highlight {{
  color: #8B1A1A;
  font-weight: bold;
}}

/* ===== SJTU BOTTOM LOGO ===== */
.sjtu-bottom {{
  position: absolute;
  bottom: 12px;
  left: 25px;
  display: flex;
  align-items: center;
  gap: 8px;
  z-index: 2;
}}
.sjtu-bottom svg {{
  width: 30px;
  height: 30px;
}}
.sjtu-bottom .text {{
  font-size: 14px;
  color: #8B1A1A;
  font-weight: bold;
  letter-spacing: 2px;
}}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="header-left">
    <!-- School of Design Logo (SVG placeholder) -->
    <div class="school-logo">
      <svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="2" width="44" height="44" rx="4" fill="none" stroke="#333" stroke-width="1.5"/>
        <text x="24" y="20" text-anchor="middle" font-size="7" font-weight="bold" fill="#333" font-family="serif">设计</text>
        <text x="24" y="30" text-anchor="middle" font-size="7" font-weight="bold" fill="#333" font-family="serif">学院</text>
        <text x="24" y="42" text-anchor="middle" font-size="4" fill="#666" font-family="serif">DESIGN</text>
      </svg>
    </div>
    <div class="school-name">
      <span class="cn">设计学院</span>
      <span class="en">SCHOOL OF DESIGN</span>
      <span class="dept">ARCHITECTURE 建筑 / DESIGN 设计</span>
      <span class="dept">LANDSCAPE ARCHITECTURE 风景园林</span>
    </div>
  </div>
  <div class="header-right">
    <div class="series-cn">交大设计建筑学<span class="bold-part">建筑技术前沿系列讲座</span></div>
    <div class="series-en">SJTU-ARCH LECTURE SERIES OF<br>BUILDING TECHNOLOGY</div>
    <div class="year">2026</div>
  </div>
</div>

<!-- BANNER -->
<div class="banner">
  <img src="data:image/jpeg;base64,{banner_b64}" alt="Urban Wind Simulation">
</div>

<!-- LECTURE ABSTRACT -->
<div class="abstract-section">
  <div class="abstract-title">
    <span class="en">LECTURE ABSTRACT</span>
    <span class="cn">主讲内容</span>
  </div>
  <div class="abstract-text">
    Have you ever considered how scaled-down building models (order of centimeters) can be used to analyze airflows around actual buildings (order of meters)? The answer lies in the concept of similarity &ndash; flows with similar dimensionless parameters behave the same way despite differences in scale, size, or other physical parameters. This seminar explores two errors commonly made in urban airflow modeling research. The behavior of airflows over buildings is determined by the dimensionless parameter Reynolds number, Re = UH/&nu;, where U is a reference wind speed, H is the building height, and &nu; is the kinematic viscosity of air. Real, full-scale buildings have H ranges from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and 10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re between scaled models and actual buildings is often circumvented using the Re-independent assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the Re-independent assumption holds true only in simple cases, such as isothermal flows over a single building. Applying this assumption to more complex scenarios involving multiple buildings or heat transfer can lead to significant errors and incorrect predictions of the overall wind field around buildings. Some recent findings on similarity in urban airflow modeling will also be shared.
  </div>
</div>

<!-- SPEAKER SECTION -->
<div class="speaker-section">
  <div class="speaker-photo-block">
    <img class="speaker-photo" src="data:image/jpeg;base64,{photo_b64}" alt="Dr. Chew Lup Wai">
    <div class="speaker-title-block">
      <strong>Dr. Chew Lup Wai</strong><br>
      Assistant Professor,<br>
      Department of the Built<br>
      Environment, College of Design<br>
      and Engineering,<br>
      National University of Singapore.
    </div>
  </div>
  <div class="speaker-info">
    <div class="speaker-name-row">
      <span class="speaker-name">CHEW LUP WAI</span>
      <span class="speaker-label">个人介绍</span>
    </div>
    <div class="speaker-bio">
      Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, College of Design and Engineering at the National University of Singapore (NUS). He is the principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the physics of flows, using both experimental and numerical approaches. In his free time, he enjoys reading, painting and traveling.
    </div>
  </div>
</div>

<!-- BOTTOM SECTION -->
<div class="bottom-section">
  <div class="bottom-left">
    <div class="lecture-title-cn">缩尺模型能否用于<br>城市气流研究？</div>
    <div class="lecture-title-en">Can We Study Urban Airflow<br>with Scaled-down Models?</div>
  </div>
  <div class="bottom-right">
    <div class="info-row">
      <span class="info-label">主办单位：</span>
      <span class="info-value">上海交通大学设计学院</span>
    </div>
    <div class="info-row">
      <span class="info-label">时　　间：</span>
      <span class="info-value"><span class="highlight">03/30 时间待定</span></span>
    </div>
    <div class="info-row">
      <span class="info-label">地　　点：</span>
      <span class="info-value">上海交通大学闵行校区<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;设计学院（具体房间待定）</span>
    </div>
    <div class="info-row">
      <span class="info-label">主 持 人：</span>
      <span class="info-value">待定</span>
    </div>
  </div>
</div>

<!-- SJTU Logo at bottom-left -->
<div class="sjtu-bottom">
  <svg viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
    <circle cx="15" cy="15" r="14" fill="none" stroke="#8B1A1A" stroke-width="1"/>
    <text x="15" y="13" text-anchor="middle" font-size="5" fill="#8B1A1A" font-family="serif" font-weight="bold">交大</text>
    <text x="15" y="19" text-anchor="middle" font-size="3.5" fill="#8B1A1A" font-family="serif">1896</text>
  </svg>
  <span class="text">上海交通大学</span>
</div>

</body>
</html>"""

Path('/home/ubuntu/poster/poster.html').write_text(html)
print("HTML poster generated successfully!")
