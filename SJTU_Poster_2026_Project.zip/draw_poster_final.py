#!/usr/bin/env python3
"""
Draw 2026 SJTU-ARCH Lecture Poster using PIL/Pillow directly.
Strictly follows 2024/2025 poster layout.
Resolution: 1240 x 1754 px (A4 @ 150dpi)
"""

from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter
import textwrap
import os

# ============================================================
# CANVAS SETUP
# ============================================================
W = 1240
H = 1754
canvas = Image.new('RGB', (W, H), '#FFFFFF')
draw = ImageDraw.Draw(canvas)

# ============================================================
# COLORS
# ============================================================
RED_DARK = (139, 26, 26)
BEIGE = (240, 235, 227)
WHITE = (255, 255, 255)
BLACK = (34, 34, 34)
GRAY = (85, 85, 85)
LIGHT_GRAY = (204, 204, 204)
RED_DARK_HEX = '#8B1A1A'

# ============================================================
# FONTS
# ============================================================
SERIF_REG = '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf'
SERIF_BOLD = '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf'
SANS_REG = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
SANS_BOLD = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
CJK_REG = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
CJK_BOLD = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'

def F(path, size):
    return ImageFont.truetype(path, size)

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def draw_text_wrapped(draw, text, x, y, max_width, font, fill, line_spacing=1.0):
    """Draw wrapped text and return final y position."""
    words = text.split()
    lines = []
    current_line = []
    
    for word in words:
        test_line = ' '.join(current_line + [word])
        bbox = font.getbbox(test_line)
        w = bbox[2] - bbox[0]
        if w <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    if current_line:
        lines.append(' '.join(current_line))
    
    line_h = font.getbbox('Ay')[3] - font.getbbox('Ay')[1]
    line_h = int(line_h * line_spacing)
    
    for line in lines:
        draw.text((x, y), line, font=font, fill=fill)
        y += line_h
    
    return y

def draw_text_justified(draw, text, x, y, max_width, font, fill, line_spacing=1.65):
    """Draw justified text and return final y position."""
    words = text.split()
    lines = []
    current_line = []
    
    for word in words:
        test_line = ' '.join(current_line + [word])
        bbox = font.getbbox(test_line)
        w = bbox[2] - bbox[0]
        if w <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    if current_line:
        lines.append(' '.join(current_line))
    
    line_h = font.getbbox('Ay')[3] - font.getbbox('Ay')[1]
    line_h = int(line_h * line_spacing)
    
    for i, line in enumerate(lines):
        if i == len(lines) - 1:
            # Last line: left-aligned
            draw.text((x, y), line, font=font, fill=fill)
        else:
            # Justify: distribute extra space
            line_words = line.split()
            if len(line_words) == 1:
                draw.text((x, y), line, font=font, fill=fill)
            else:
                total_word_w = sum(font.getbbox(w)[2] - font.getbbox(w)[0] for w in line_words)
                total_space = max_width - total_word_w
                gap = total_space / (len(line_words) - 1)
                cx = x
                for j, word in enumerate(line_words):
                    draw.text((int(cx), y), word, font=font, fill=fill)
                    ww = font.getbbox(word)[2] - font.getbbox(word)[0]
                    cx += ww + gap
        y += line_h
    
    return y

# ============================================================
# LOAD IMAGES
# ============================================================
logo_img = Image.open('/home/ubuntu/poster/school_logo.png').convert('RGBA')
banner_img = Image.open('/home/ubuntu/poster/banner_new.png').convert('RGB')
photo_img = Image.open('/home/ubuntu/poster/photo.jpg').convert('RGB')
sjtu_img = Image.open('/home/ubuntu/poster/sjtu_logo_text.jpg').convert('RGB')

# ============================================================
# LAYOUT CONSTANTS
# ============================================================
PAD = 40  # horizontal padding
y = 0

# ============================================================
# SECTION 1: HEADER
# ============================================================
HEADER_H = 115
header_bg = Image.new('RGB', (W, HEADER_H), WHITE)
canvas.paste(header_bg, (0, 0))

# Logo: scale to height 80px
logo_h = 80
logo_w = int(logo_img.width * logo_h / logo_img.height)
logo_resized = logo_img.resize((logo_w, logo_h), Image.LANCZOS)
# Paste with alpha
logo_bg = Image.new('RGB', (logo_w, logo_h), WHITE)
logo_bg.paste(logo_resized, mask=logo_resized.split()[3])
canvas.paste(logo_bg, (PAD, 20))

# Right side: series title + year
# Series CN
f_series_cn = F(CJK_REG, 28)
f_series_cn_bold = F(CJK_BOLD, 28)
f_series_en = F(SANS_REG, 18)
f_year = F(SERIF_BOLD, 100)

# Draw series CN text (mix regular + bold)
series_cn_1 = '交大设计建筑学'
series_cn_2 = '建筑技术前沿系列讲座'

# Measure
bbox1 = f_series_cn.getbbox(series_cn_1)
w1 = bbox1[2] - bbox1[0]
bbox2 = f_series_cn_bold.getbbox(series_cn_2)
w2 = bbox2[2] - bbox2[0]
total_cn_w = w1 + w2

# Right-align
x_cn = W - PAD - total_cn_w
draw.text((x_cn, 18), series_cn_1, font=f_series_cn, fill=BLACK)
draw.text((x_cn + w1, 18), series_cn_2, font=f_series_cn_bold, fill=BLACK)

# Series EN
series_en = 'SJTU-ARCH LECTURE SERIES OF  BUILDING TECHNOLOGY'
bbox_en = f_series_en.getbbox(series_en)
w_en = bbox_en[2] - bbox_en[0]
draw.text((W - PAD - w_en, 52), series_en, font=f_series_en, fill=GRAY)

# Year
year_text = '2026'
bbox_year = f_year.getbbox(year_text)
w_year = bbox_year[2] - bbox_year[0]
draw.text((W - PAD - w_year, 10), year_text, font=f_year, fill=RED_DARK)

y = HEADER_H

# ============================================================
# SECTION 2: BANNER IMAGE (full, no crop)
# ============================================================
banner_w = W
banner_h = int(banner_img.height * W / banner_img.width)
banner_resized = banner_img.resize((banner_w, banner_h), Image.LANCZOS)
canvas.paste(banner_resized, (0, y))
y += banner_h

# ============================================================
# SECTION 3: LECTURE ABSTRACT
# ============================================================
y += 28  # top padding

# Heading
f_heading_en = F(SERIF_BOLD, 34)
f_heading_cn = F(CJK_BOLD, 28)

draw.text((PAD, y), 'LECTURE ABSTRACT', font=f_heading_en, fill=RED_DARK)
bbox_he = f_heading_en.getbbox('LECTURE ABSTRACT')
w_he = bbox_he[2] - bbox_he[0]
draw.text((PAD + w_he + 20, y + 4), '主讲内容', font=f_heading_cn, fill=BLACK)

y += 44
# Divider line
draw.line([(PAD, y), (W - PAD, y)], fill=LIGHT_GRAY, width=2)
y += 14

# Abstract text
f_body = F(SERIF_REG, 22)
abstract_text = (
    "Have you ever considered how scaled-down building models (order of centimeters) can be used to "
    "analyze airflows around actual buildings (order of meters)? The answer lies in the concept of "
    "similarity - flows with similar dimensionless parameters behave the same way despite differences "
    "in scale, size, or other physical parameters. This seminar explores two errors commonly made in "
    "urban airflow modeling research. The behavior of airflows over buildings is determined by the "
    "dimensionless parameter Reynolds number, Re = UH/v, where U is a reference wind speed, H is the "
    "building height, and v is the kinematic viscosity of air. Real, full-scale buildings have H ranges "
    "from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and "
    "10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, "
    "resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re "
    "between scaled models and actual buildings is often circumvented using the Re-independent "
    "assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to "
    "real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the "
    "Re-independent assumption holds true only in simple cases, such as isothermal flows over a single "
    "building. Applying this assumption to more complex scenarios involving multiple buildings or heat "
    "transfer can lead to significant errors and incorrect predictions of the overall wind field around "
    "buildings. Some recent findings on similarity in urban airflow modeling will also be shared."
)

y = draw_text_justified(draw, abstract_text, PAD, y, W - 2*PAD, f_body, BLACK, line_spacing=1.65)
y += 28  # bottom padding

# ============================================================
# SECTION 4: SPEAKER
# ============================================================
PHOTO_SIZE = 270
PHOTO_X = PAD
PHOTO_Y = y

# Photo
photo_resized = photo_img.resize((PHOTO_SIZE, PHOTO_SIZE), Image.LANCZOS)
canvas.paste(photo_resized, (PHOTO_X, PHOTO_Y))

# Caption below photo
f_caption_bold = F(SERIF_BOLD, 18)
f_caption = F(SERIF_REG, 18)
cap_y = PHOTO_Y + PHOTO_SIZE + 10
draw.text((PHOTO_X, cap_y), 'Dr. Chew Lup Wai', font=f_caption_bold, fill=BLACK)
cap_y += 24
caption_lines = [
    'Assistant Professor,',
    'Department of the Built',
    'Environment, College of Design',
    'and Engineering,',
    'National University of',
    'Singapore (NUS).',
]
for line in caption_lines:
    draw.text((PHOTO_X, cap_y), line, font=f_caption, fill=BLACK)
    cap_y += 24

# Right side: name + bio
RIGHT_X = PHOTO_X + PHOTO_SIZE + 35
RIGHT_W = W - RIGHT_X - PAD

# Speaker name
f_speaker_name = F(SERIF_BOLD, 42)
f_speaker_label = F(CJK_BOLD, 28)

draw.text((RIGHT_X, y), 'CHEW LUP WAI', font=f_speaker_name, fill=BLACK)
bbox_name = f_speaker_name.getbbox('CHEW LUP WAI')
w_name = bbox_name[2] - bbox_name[0]
draw.text((RIGHT_X + w_name + 18, y + 8), '个人介绍', font=f_speaker_label, fill=BLACK)

y_bio = y + 52

bio_text = (
    "Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, "
    "College of Design and Engineering at the National University of Singapore (NUS). He is the "
    "principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He "
    "obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior "
    "to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies "
    "in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the "
    "physics of flows, using both experimental and numerical approaches. In his free time, he "
    "enjoys reading, painting and traveling."
)

draw_text_justified(draw, bio_text, RIGHT_X, y_bio, RIGHT_W, f_body, BLACK, line_spacing=1.65)

# Advance y to after the speaker section (photo + caption height)
y_after_speaker = PHOTO_Y + PHOTO_SIZE + 10 + len(caption_lines) * 24 + 24 + 30
y = max(y_after_speaker, y_bio + 200)  # ensure enough space

# ============================================================
# SECTION 5: BOTTOM BAR
# ============================================================
BOTTOM_H = 310
BOTTOM_Y = H - BOTTOM_H

# Left half: dark red
draw.rectangle([(0, BOTTOM_Y), (W//2, H)], fill=RED_DARK)

# Watermark text (very faint)
f_watermark = F(SERIF_BOLD, 80)
wm_text = 'SHANGHAI JIAO TONG UNIVERSITY'
draw.text((10, BOTTOM_Y + 10), wm_text, font=f_watermark, fill=(255, 255, 255, 14))

# Lecture title CN
f_title_cn = F(CJK_BOLD, 52)
f_title_en = F(SERIF_REG, 26)

title_cn_lines = ['缩尺模型能否用于', '城市气流研究？']
title_y = BOTTOM_Y + 35
for line in title_cn_lines:
    draw.text((PAD, title_y), line, font=f_title_cn, fill=WHITE)
    bbox_tl = f_title_cn.getbbox(line)
    title_y += (bbox_tl[3] - bbox_tl[1]) + 8

title_y += 12
title_en_lines = ['Can We Study Urban Airflow', 'with Scaled-down Models?']
for line in title_en_lines:
    draw.text((PAD, title_y), line, font=f_title_en, fill=WHITE)
    bbox_te = f_title_en.getbbox(line)
    title_y += (bbox_te[3] - bbox_te[1]) + 6

# SJTU logo at bottom-left
sjtu_h = 40
sjtu_w = int(sjtu_img.width * sjtu_h / sjtu_img.height)
sjtu_resized = sjtu_img.resize((sjtu_w, sjtu_h), Image.LANCZOS)
# Invert to white
sjtu_inv = ImageOps.invert(sjtu_resized)
# Blend with transparency
canvas.paste(sjtu_inv, (PAD, H - sjtu_h - 18))

# Right half: beige
draw.rectangle([(W//2, BOTTOM_Y), (W, H)], fill=BEIGE)

# Watermark
f_wm2 = F(SERIF_BOLD, 70)
draw.text((W//2 + 20, BOTTOM_Y + 60), 'SCHOOL OF DESIGN', font=f_wm2, fill=(139, 26, 26))
# Make it very faint by drawing over with beige at high opacity - use a separate approach
# Actually just use very light color
wm_img = Image.new('RGBA', (W//2, BOTTOM_H), (0, 0, 0, 0))
wm_draw = ImageDraw.Draw(wm_img)
wm_draw.text((20, 60), 'SCHOOL OF DESIGN', font=f_wm2, fill=(139, 26, 26, 10))
canvas_rgba = canvas.convert('RGBA')
canvas_rgba.paste(wm_img, (W//2, BOTTOM_Y), wm_img)
canvas = canvas_rgba.convert('RGB')
draw = ImageDraw.Draw(canvas)

# Info rows
f_label = F(CJK_BOLD, 26)
f_value = F(CJK_REG, 26)
f_value_en = F(SERIF_REG, 24)

INFO_X = W//2 + 40
info_y = BOTTOM_Y + 30

info_rows = [
    ('主办单位：', '上海交通大学设计学院', False),
    ('时　　间：', '03/30 时间待定', True),
    ('地　　点：', '上海交通大学闵行校区\n设计学院（具体房间待定）', False),
    ('主 持 人：', '待定', False),
]

for label, value, is_red in info_rows:
    draw.text((INFO_X, info_y), label, font=f_label, fill=RED_DARK)
    bbox_lbl = f_label.getbbox(label)
    lbl_w = bbox_lbl[2] - bbox_lbl[0]
    val_color = RED_DARK if is_red else BLACK
    if '\n' in value:
        lines = value.split('\n')
        vx = INFO_X + lbl_w + 5
        vy = info_y
        for vline in lines:
            draw.text((vx, vy), vline, font=f_value, fill=val_color)
            bbox_vl = f_value.getbbox(vline)
            vy += (bbox_vl[3] - bbox_vl[1]) + 4
        info_y = vy + 14
    else:
        draw.text((INFO_X + lbl_w + 5, info_y), value, font=f_value, fill=val_color)
        bbox_v = f_value.getbbox(value)
        info_y += (bbox_v[3] - bbox_v[1]) + 18

# ============================================================
# SAVE
# ============================================================
canvas.save('/home/ubuntu/poster/poster_2026_final.jpg', 'JPEG', quality=95, dpi=(150, 150))
canvas.save('/home/ubuntu/poster/poster_2026_final.png', 'PNG', dpi=(150, 150))
print(f"Poster saved! Size: {canvas.size}")
print(f"Content ends at y={y}, bottom bar at y={BOTTOM_Y}")
if y > BOTTOM_Y:
    print(f"WARNING: Content overlaps bottom bar by {y - BOTTOM_Y}px!")
else:
    print(f"OK: Gap between content and bottom bar: {BOTTOM_Y - y}px")
