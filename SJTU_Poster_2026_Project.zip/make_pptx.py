"""
Generate editable PPTX poster for 2026 SJTU-ARCH Lecture Series
Speaker: CHEW Lup Wai
Slide size: A4 portrait (21cm x 29.7cm)
"""

from pptx import Presentation
from pptx.util import Cm, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches
import copy
from lxml import etree
import os

# ============================================================
# SETUP
# ============================================================
prs = Presentation()

# A4 portrait
prs.slide_width  = Cm(21)
prs.slide_height = Cm(29.7)

slide_layout = prs.slide_layouts[6]  # blank
slide = prs.slides.add_slide(slide_layout)

W = prs.slide_width   # Emu
H = prs.slide_height  # Emu

# ============================================================
# COLORS
# ============================================================
RED_DARK = RGBColor(139, 26, 26)
BEIGE    = RGBColor(240, 235, 227)
WHITE    = RGBColor(255, 255, 255)
BLACK    = RGBColor(34, 34, 34)
GRAY     = RGBColor(85, 85, 85)
LIGHT_GRAY = RGBColor(180, 180, 180)

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def add_rect(slide, x, y, w, h, fill_color=None, line_color=None, line_width=None):
    from pptx.util import Emu
    shape = slide.shapes.add_shape(
        1,  # MSO_SHAPE_TYPE.RECTANGLE
        x, y, w, h
    )
    shape.line.fill.background()
    if fill_color:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill_color
    else:
        shape.fill.background()
    if line_color:
        shape.line.color.rgb = line_color
        if line_width:
            shape.line.width = line_width
    else:
        shape.line.fill.background()
    return shape

def add_textbox(slide, x, y, w, h, text, font_name, font_size, bold=False, italic=False,
                color=BLACK, align=PP_ALIGN.LEFT, wrap=True, line_spacing=None):
    from pptx.util import Pt as _Pt
    from pptx.oxml.ns import qn
    txBox = slide.shapes.add_textbox(x, y, w, h)
    tf = txBox.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    if line_spacing:
        pPr = p._pPr
        if pPr is None:
            pPr = p._p.get_or_add_pPr()
        lnSpc = etree.SubElement(pPr, qn('a:lnSpc'))
        spcPct = etree.SubElement(lnSpc, qn('a:spcPct'))
        spcPct.set('val', str(int(line_spacing * 100000)))
    run = p.add_run()
    run.text = text
    run.font.name = font_name
    run.font.size = _Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txBox

def add_picture(slide, img_path, x, y, w, h=None):
    if h:
        pic = slide.shapes.add_picture(img_path, x, y, w, h)
    else:
        pic = slide.shapes.add_picture(img_path, x, y, w)
    return pic

def add_line(slide, x1, y1, x2, y2, color, width_pt=0.75):
    from pptx.util import Pt
    connector = slide.shapes.add_connector(1, x1, y1, x2, y2)
    connector.line.color.rgb = color
    connector.line.width = Pt(width_pt)
    return connector

# ============================================================
# DIMENSIONS (proportional to A4)
# Poster image was 1240x1764px, A4 = 21x29.7cm
# Scale: 21cm / 1240px = 0.01694 cm/px
# ============================================================
def px(n):
    """Convert pixel (at 1240px width) to EMU"""
    return int(n * (Cm(21) / 1240))

PAD = px(40)

# ============================================================
# SECTION 1: HEADER (130px -> ~2.2cm)
# ============================================================
HEADER_H = px(130)

# White background for header
add_rect(slide, 0, 0, W, HEADER_H, fill_color=WHITE)

# School of Design logo (left)
LOGO_H = px(90)
from PIL import Image as PILImage
logo_img = PILImage.open('/home/ubuntu/poster/school_logo.png')
logo_aspect = logo_img.width / logo_img.height
LOGO_W = int(LOGO_H * logo_aspect)
add_picture(slide, '/home/ubuntu/poster/school_logo.png',
            PAD, px(20), LOGO_W, LOGO_H)

# Right side: series title + year
# "交大设计建筑学建筑技术前沿系列讲座"
title_x = px(420)
title_w = W - title_x - PAD

# Chinese title line
tb_cn = add_textbox(slide, title_x, px(18), title_w, px(40),
                    '交大设计建筑学建筑技术前沿系列讲座',
                    'Noto Serif CJK SC', 14, bold=False, color=BLACK,
                    align=PP_ALIGN.RIGHT)

# English title line
tb_en = add_textbox(slide, title_x, px(52), title_w - px(100), px(36),
                    'SJTU-ARCH LECTURE SERIES OF\nBUILDING TECHNOLOGY',
                    'Liberation Sans', 8.5, bold=False, color=GRAY,
                    align=PP_ALIGN.RIGHT)
tb_en.text_frame.word_wrap = True

# Year "2026"
year_w = px(120)
year_x = W - PAD - year_w
add_textbox(slide, year_x - px(10), px(38), year_w + px(20), px(72),
            '2026',
            'Liberation Sans', 46, bold=True, color=BLACK,
            align=PP_ALIGN.RIGHT)

# Thin separator line below header
add_line(slide, 0, HEADER_H, W, HEADER_H, LIGHT_GRAY, 0.5)

# ============================================================
# SECTION 2: BANNER IMAGE (banner_new.png, full width)
# ============================================================
BANNER_Y = HEADER_H
banner_img = PILImage.open('/home/ubuntu/poster/banner_new.png')
banner_aspect = banner_img.width / banner_img.height  # 647/374 = 1.73
BANNER_H = int(W / banner_aspect)
add_picture(slide, '/home/ubuntu/poster/banner_new.png',
            0, BANNER_Y, W, BANNER_H)

# ============================================================
# SECTION 3: LECTURE ABSTRACT
# ============================================================
ABSTRACT_Y = BANNER_Y + BANNER_H
abstract_pad_top = px(14)
y_cur = ABSTRACT_Y + abstract_pad_top

# "LECTURE ABSTRACT  主讲内容" heading
heading_h = px(42)
# Bold red "LECTURE ABSTRACT"
tb_head1 = add_textbox(slide, PAD, y_cur, px(380), heading_h,
                       'LECTURE ABSTRACT',
                       'Liberation Serif', 18, bold=True, color=RED_DARK)
# CJK "主讲内容"
tb_head2 = add_textbox(slide, PAD + px(310), y_cur + px(4), px(160), heading_h,
                       '主讲内容',
                       'Noto Serif CJK SC', 14, bold=False, color=BLACK)

y_cur += heading_h

# Divider line
add_line(slide, PAD, y_cur, W - PAD, y_cur, LIGHT_GRAY, 0.75)
y_cur += px(14)

# Abstract text
abstract_text = (
    "Have you ever considered how scaled-down building models (order of centimeters) can be used to "
    "analyze airflows around actual buildings (order of meters)? The answer lies in the concept of "
    "similarity - flows with similar dimensionless parameters behave the same way despite differences "
    "in scale, size, or other physical parameters. This seminar explores two errors commonly made in "
    "urban airflow modeling research. The behavior of airflows over buildings is determined by the "
    "dimensionless parameter Reynolds number, Re = UH/v, where U is a reference wind speed, H is the "
    "building height, and v is the kinematic viscosity of air. Real, full-scale buildings have H ranges "
    "from several meters to hundreds of meters, resulting in Re typically between 1,000,000 and "
    "10,000,000. In contrast, wind tunnel experiments involve models with H measured in centimeters, "
    "resulting in Re around 1,000 to 10,000, much lower than those at full scale. This disparity in Re "
    "between scaled models and actual buildings is often circumvented using the Re-independent "
    "assumption, which enables us to study airflow patterns in wind tunnels and apply the findings to "
    "real buildings. Through experiments and computational fluid dynamics, I will demonstrate that the "
    "Re-independent assumption holds true only in simple cases, such as isothermal flows over a single "
    "building. Applying this assumption to more complex scenarios involving multiple buildings or heat "
    "transfer can lead to significant errors and incorrect predictions of the overall wind field around "
    "buildings. Some recent findings on similarity in urban airflow modeling will also be shared."
)

# Estimate abstract text height: ~11 lines at line height ~px(25)
ABSTRACT_TEXT_H = px(300)
tb_abstract = add_textbox(slide, PAD, y_cur, W - 2*PAD, ABSTRACT_TEXT_H,
                          abstract_text,
                          'Liberation Serif', 10, bold=False, color=BLACK,
                          align=PP_ALIGN.JUSTIFY, wrap=True, line_spacing=1.55)
y_cur += ABSTRACT_TEXT_H + px(10)

# ============================================================
# SECTION 4: SPEAKER
# ============================================================
SPEAKER_Y = y_cur
PHOTO_SIZE = px(140)
PHOTO_X = PAD
PHOTO_Y = SPEAKER_Y + px(10)

# Photo (square crop)
add_picture(slide, '/home/ubuntu/poster/photo.jpg',
            PHOTO_X, PHOTO_Y, PHOTO_SIZE, PHOTO_SIZE)

# Caption below photo
cap_y = PHOTO_Y + PHOTO_SIZE + px(7)
add_textbox(slide, PHOTO_X, cap_y, PHOTO_SIZE + px(20), px(22),
            'Dr. Chew Lup Wai',
            'Liberation Serif', 9, bold=True, color=BLACK)
cap_y += px(20)
for line in ['Assistant Professor,', 'College of Design & Engineering,', 'NUS, Singapore.']:
    add_textbox(slide, PHOTO_X, cap_y, PHOTO_SIZE + px(20), px(20),
                line, 'Liberation Serif', 9, bold=False, color=BLACK)
    cap_y += px(20)

# Right side: name + bio
RIGHT_X = PHOTO_X + PHOTO_SIZE + px(28)
RIGHT_W = W - RIGHT_X - PAD

# Speaker name "CHEW LUP WAI  个人介绍"
name_y = SPEAKER_Y + px(10)
add_textbox(slide, RIGHT_X, name_y, px(380), px(44),
            'CHEW LUP WAI',
            'Liberation Serif', 22, bold=True, color=BLACK)
add_textbox(slide, RIGHT_X + px(310), name_y + px(4), px(120), px(36),
            '个人介绍',
            'Noto Serif CJK SC', 14, bold=False, color=BLACK)

# Bio text
bio_text = (
    "Dr. Lup Wai Chew is an Assistant Professor in the Department of the Built Environment, "
    "College of Design and Engineering at the National University of Singapore (NUS). He is the "
    "principal investigator of the Airflow-Buildings-Cities Laboratory and CoolNUS Project. He "
    "obtained his PhD in Mechanical Engineering from Massachusetts Institute of Technology. Prior "
    "to NUS, he worked as a postdoctoral scholar at Stanford University. His specialization lies "
    "in urban airflow modelling, focusing on natural ventilation, outdoor wind field, and the "
    "physics of flows, using both experimental and numerical approaches. In his free time, he "
    "enjoys reading, painting and traveling."
)
BIO_H = px(200)
tb_bio = add_textbox(slide, RIGHT_X, name_y + px(44), RIGHT_W, BIO_H,
                     bio_text,
                     'Liberation Serif', 10, bold=False, color=BLACK,
                     align=PP_ALIGN.JUSTIFY, wrap=True, line_spacing=1.55)

SPEAKER_END_Y = SPEAKER_Y + PHOTO_SIZE + px(10) + px(20) + 3*px(20) + px(20)

# ============================================================
# SECTION 5: BOTTOM BAR
# ============================================================
BOTTOM_Y = max(SPEAKER_END_Y, SPEAKER_Y + px(230))
BOTTOM_H_emu = H - BOTTOM_Y

# Left half: dark red background
add_rect(slide, 0, BOTTOM_Y, W//2, BOTTOM_H_emu, fill_color=RED_DARK)

# Right half: beige background
add_rect(slide, W//2, BOTTOM_Y, W//2, BOTTOM_H_emu, fill_color=BEIGE)

# Lecture title (left, white text)
title_cn_lines = ['缩尺模型能否用于', '城市气流研究？']
title_y = BOTTOM_Y + px(28)
for line in title_cn_lines:
    add_textbox(slide, PAD, title_y, W//2 - PAD*2, px(58),
                line, 'Noto Serif CJK SC', 26, bold=True, color=WHITE)
    title_y += px(56)

title_y += px(8)
title_en_lines = ['Can We Study Urban Airflow', 'with Scaled-down Models?']
for line in title_en_lines:
    add_textbox(slide, PAD, title_y, W//2 - PAD*2, px(32),
                line, 'Liberation Serif', 13, bold=False, color=WHITE)
    title_y += px(30)

# SJTU logo (bottom-left, white/inverted)
from PIL import Image as PILImage, ImageOps
sjtu_img = PILImage.open('/home/ubuntu/poster/sjtu_logo_text.jpg').convert('RGB')
sjtu_inv = ImageOps.invert(sjtu_img)
sjtu_inv_path = '/home/ubuntu/poster/sjtu_logo_inv.png'
sjtu_inv.save(sjtu_inv_path)
SJTU_H = px(38)
sjtu_aspect = sjtu_img.width / sjtu_img.height
SJTU_W = int(SJTU_H * sjtu_aspect)
add_picture(slide, sjtu_inv_path,
            PAD, H - SJTU_H - px(16), SJTU_W, SJTU_H)

# Info rows (right side)
INFO_X = W//2 + px(36)
info_y = BOTTOM_Y + px(28)
row_h = px(34)

rows = [
    ('主办单位：', '上海交通大学设计学院'),
    ('时　　间：', '03/30  时间待定'),
    ('地　　点：', '上海交通大学闵行校区\n设计学院（具体房间待定）'),
    ('主 持 人：', '待定'),
]

for label, value in rows:
    # Label (bold, dark red)
    add_textbox(slide, INFO_X, info_y, px(120), row_h,
                label, 'Noto Serif CJK SC', 12, bold=True, color=RED_DARK)
    # Value
    if '\n' in value:
        lines_v = value.split('\n')
        vy = info_y
        for vl in lines_v:
            add_textbox(slide, INFO_X + px(110), vy, W - INFO_X - px(110) - PAD, px(28),
                        vl, 'Noto Serif CJK SC', 12, bold=False, color=BLACK)
            vy += px(26)
        info_y = vy + px(8)
    else:
        add_textbox(slide, INFO_X + px(110), info_y, W - INFO_X - px(110) - PAD, row_h,
                    value, 'Noto Serif CJK SC', 12, bold=False, color=BLACK)
        info_y += row_h + px(4)

# ============================================================
# SAVE
# ============================================================
out_path = '/home/ubuntu/poster/poster_2026_ChewLupWai.pptx'
prs.save(out_path)
print(f"PPTX saved: {out_path}")
print(f"Slide size: {prs.slide_width.cm:.1f} x {prs.slide_height.cm:.1f} cm")
